public class Mammal {
   public static int EnergyLevel = 100;


   public int displayEnergy() {
      return EnergyLevel;
   }


   
   }
